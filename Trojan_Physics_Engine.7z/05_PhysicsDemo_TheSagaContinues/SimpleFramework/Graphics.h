#pragma once

#define GLFW_INCLUDE_NONE
#include "glfw3.h"
#include "glad.h"