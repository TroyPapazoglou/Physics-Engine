#pragma once

#include "Object.h"


class Box : public Object
{
public:
	float width = 1.0f;
	float height = 1.0f;

	Box(float x, float y, float width, float height, float mass);

	virtual void DebugDraw(LineRenderer* lines) const;

	virtual ShapeType GetType() const override {return ShapeType::Box;}

};