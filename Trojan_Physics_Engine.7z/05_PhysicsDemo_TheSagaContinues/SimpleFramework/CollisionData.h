#pragma once
#include "Maths.h"
#include "Object.h"

struct CollisionData
{
	Vec2 normal;	//Points from 1 to 2
	float depth = -1.0f;


	Object* object1 = nullptr;
	Object* object2 = nullptr;


	void PerformDepenetrationStep();

	CollisionData& GetFlipped()
	{
		normal *= -1;
		return *this;
	}

	bool IsCollision() const { return depth > 0.0f; }
};
