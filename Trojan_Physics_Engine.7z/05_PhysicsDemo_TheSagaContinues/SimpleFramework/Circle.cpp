#include "Circle.h"

Circle::Circle(float x, float y, float rad, float mass) : Object(x, y, mass), radius(rad)
{

}

void Circle::SetRadius(float rad)
{
	radius = rad;
	mass = radius * radius;
}

void Circle::DebugDraw(LineRenderer* lines) const
{
	lines->DrawCircle(position, radius);	
}
