#include "DotClicker.h"
#include "imgui.h"
#include <iostream>
#include <sstream>
#include <iomanip>


DotClicker::DotClicker()
{
	//Your initialisation code goes here!
	planeNormal = glm::normalize(Vec2(2.0f, 1.0f));
}

void DotClicker::Update(float delta)
{
	if (currentlyGrabbedPoint != -1)
	{
		Vec2 snappedPos;
		snappedPos.x = round(cursorPos.x * 10.0f) / 10.0f;
		snappedPos.y = round(cursorPos.y * 10.0f) / 10.0f;
		points[currentlyGrabbedPoint] = snappedPos;
	}



	lines->SetColour({ 1, 1, 1 });
	for (Vec2 point : points)
	{
		lines->DrawCircle(point, pointRadius);
	}


	//planeNormal = glm::normalize(cursorPos);


	std::stringstream stringWereBuilding;


	displacement = glm::dot(cursorPos, planeNormal);


	//Almost the entirety of circle to plane collision
	float circleOverlapAmount = -(glm::dot(cursorPos, planeNormal) - displacement - circleRadius);
	stringWereBuilding << glm::dot(cursorPos, planeNormal);


	//lines->SetColour(circleOverlapAmount > 0.0f ? Vec3(1.0f, 0.0f, 0.0f) : Vec3(1, 1, 1));
	//lines->DrawCircle(cursorPos, circleRadius);
	//lines->SetColour(Vec3(1, 1, 1));
	//
	//lines->RenderString(stringWereBuilding.str(), cursorPos, 0.5f);

	lines->DrawLineSegment(planeNormal * displacement, planeNormal * displacement + planeNormal);




	Vec2 planeTangent;
	planeTangent.x = planeNormal.y;
	planeTangent.y = -planeNormal.x;

	lines->DrawLineSegment(planeNormal * displacement + planeTangent * 1000.0f, planeNormal * displacement - planeTangent * 1000.0f);

}
void DotClicker::OnLeftClick()
{
	//Try to grab vert here, or place a new one if there isn't one.
	int thisClickIndex = GetPointAtPosition(cursorPos);
	if (thisClickIndex == -1)
	{
		Vec2 snappedPos;
		snappedPos.x = round(cursorPos.x * 10.0f) / 10.0f;
		snappedPos.y = round(cursorPos.y * 10.0f) / 10.0f;
		points.push_back(snappedPos);
	}
	else
	{
		currentlyGrabbedPoint = thisClickIndex;
	}
}
void DotClicker::OnRightClick()
{
	//Try to delete vert here.
	int thisClickIndex = GetPointAtPosition(cursorPos);
	if (thisClickIndex != -1)
	{
		currentlyGrabbedPoint = -1;	//Ungrab anything.
		points.erase(points.begin() + thisClickIndex);
	}
}

void DotClicker::OnLeftRelease()
{
	currentlyGrabbedPoint = -1;
}

int DotClicker::GetPointAtPosition(Vec2 position)
{
	for (int i = 0; i < points.size(); i++)
	{
		if (glm::length(points[i] - position) < pointRadius)
		{
			return i;
		}
	}
	return -1;
}
