#pragma once

#include "Object.h"

class Circle : public Object
{
public:
	float radius = 1.0f;

	Circle(float x, float y, float rad, float mass);

	void SetRadius(float rad);
	float GetRadius() const { return radius; }

	virtual void DebugDraw(LineRenderer* lines) const override;

	virtual ShapeType GetType() const override { return ShapeType::Circle; }
};