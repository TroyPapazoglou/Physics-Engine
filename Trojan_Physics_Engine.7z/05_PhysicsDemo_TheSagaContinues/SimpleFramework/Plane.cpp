#include "Plane.h"

Plane::Plane(glm::vec2 normal, float x, float y, float displacement) : Object(x, y, mass), displacement(displacement), planeNormal(normal)
{	
	mass = 0;
	planeTangent.x = planeNormal.y;
	planeTangent.y = -planeNormal.x;
}

Plane::~Plane()
{
}

void Plane::DebugDraw(LineRenderer* lines) const
{
	
	lines->SetColour(Vec3(1, 0, 0));
	lines->DrawLineSegment(planeNormal * displacement + planeTangent * 1000.0f, planeNormal * displacement - planeTangent * 1000.0f);
	lines->SetColour(Vec3(1, 1, 1));
}