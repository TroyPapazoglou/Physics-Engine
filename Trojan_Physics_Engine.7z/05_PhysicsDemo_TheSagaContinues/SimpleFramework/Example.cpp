#include "Example.h"
#include "imgui.h"


Example::Example()
{
	//Your initialisation code goes here!
}

void Example::Update(float delta)
{
}

void Example::OnLeftClick()
{
}
