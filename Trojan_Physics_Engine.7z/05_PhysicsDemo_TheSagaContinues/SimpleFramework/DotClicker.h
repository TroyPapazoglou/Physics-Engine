#pragma once

#include "ApplicationHarness.h"
#include "Maths.h"
#include <vector>

//A simple project that allows the user to place points by clicking, drag them around,
//and remove them by right-clicking on them. The order of the dots is stable but there's
//no built-in way to mess with the order.

//Can serve as a base for demonstrating other algorithms, like gift-wrapping or ear-pruning.

class DotClicker : public Application
{

	Vec2 planeNormal;
	float displacement = 2.0f;

	float circleRadius = 1.2f;

	std::vector<Vec2> points;
	int currentlyGrabbedPoint = -1;


	float pointRadius = 0.1f;

public:
	DotClicker();

	void Update(float delta);

	void OnLeftClick() override;
	void OnLeftRelease() override;
	void OnRightClick() override;

	int GetPointAtPosition(Vec2 position);
};