#include "Trojan.h"
#include "CollisionFunctions.h"
#include "Circle.h"
#include "Plane.h"
#include "Box.h"

Trojan::Trojan()
{
	
	
	objects.push_back(new Plane(glm::normalize(Vec2(0, -10)), 0, 0, -10)); 
	objects.push_back(new Plane(glm::normalize(Vec2(0, 10)), 0, 0, -10));
	objects.push_back(new Plane(glm::normalize(Vec2(-10, 0)), 0, 0, -10)); 
	objects.push_back(new Plane(glm::normalize(Vec2(10, 0)), 0, 0, -10));

	


	

	objects.push_back(new Box(0, 0, 2, 2, 1)); 
	objects.push_back(new Box(0, 0, 2, 2, 1));
	objects.push_back(new Box(0, 0, 2, 2, 1));
	//objects.push_back(new Box(2, 0, 2, 2, 1));
	///*objects.push_back(new Box(3, 0, 3, 2, 1));*/

	objects.push_back(new Circle(0, 0, 1, 1));
	objects.push_back(new Circle(0, 0, 1, 1));
	objects.push_back(new Circle(0, 0, 1, 1));
	//objects.push_back(new Circle(6, 0, 0.5f, 1));
	//objects.push_back(new Circle(6, 5, 0.5f, 1));
	//objects.push_back(new Circle(1, 3, 0.5f));
	//objects.push_back(new Circle(1, 4, 0.5f));
	//objects.push_back(new Circle(1, 5, 0.5f));
	
	
}


void Trojan::Update(float delta)
{
	
	for (Object* object : objects)
	{
		object->Update(delta);
	}

	for (int iteration = 0; iteration < 10; iteration++)
	{
		std::vector<CollisionData> collisionDatums;
		for (int i = 0; i < objects.size(); i++)
		{
			for (int j = i + 1; j < objects.size(); j++)
			{
				CollisionData theCollision = GetCollision(objects[i], objects[j]);
				if (theCollision.IsCollision())
				{
					collisionDatums.push_back(theCollision);
				}
			}
		}
		for (CollisionData& thisData : collisionDatums)
		{
			thisData.PerformDepenetrationStep();
		}
	}
	

	for (Object* object : objects)
	{
		object->DebugDraw(lines);
	}

}

int Trojan::GetPointAtPosition(Vec2 position)
{
	for (int i = 0; i < points.size(); i++)
	{
		if (glm::length(points[i] - position) < pointRadius)
		{
			return i;
		}
	}
	return -1;
}

void Trojan::OnLeftClick()
{
	for (Object* object : objects)
	{
		Vec2 toCursor = cursorPos - object->position;
		toCursor = glm::normalize(toCursor);
		object->AddImpulse(toCursor * 20.0f);
	}
}

void Trojan::OnQClick()
{
	objects.push_back(new Circle(cursorPos.x, cursorPos.y, 1.0f, 1));
}

void Trojan::OnEClick()
{
	objects.push_back(new Box(cursorPos.x, cursorPos.y, 2, 2, 1));
}

