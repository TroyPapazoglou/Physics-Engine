#pragma once

#include "Application.h"
#include "Object.h"
#include <vector>


class Trojan : public Application
{
private:
	std::vector<Object*> objects;
	std::vector<Vec2> points;
	float pointRadius = 0.1f;

public:
	Trojan();

	void Update(float delta) override;

	void OnLeftClick() override;	
	void OnQClick() override;
	void OnEClick() override;

	int GetPointAtPosition(Vec2 position);
		

};