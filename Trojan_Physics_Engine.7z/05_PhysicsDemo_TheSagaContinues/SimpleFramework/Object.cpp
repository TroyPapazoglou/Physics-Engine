#include "Object.h"

Object::Object(float xPos, float yPos, float mass): position(xPos, yPos), velocity(0.0f, 0.0f), acceleration(0.0f, 0.0f),	forceAccumulator(0.0f, 0.0f), mass(mass)
{
}

void Object::Update(float delta)
{
	
	Vec2 gravity = { 0.0f, -9.0f };
	if (mass != 0)
		forceAccumulator += gravity / mass;
	acceleration = forceAccumulator * mass;

	velocity += acceleration * delta;
	position += velocity * delta;

	forceAccumulator = { 0, 0 };
}

void Object::SetMass(float m_mass)
{
	mass = m_mass;
}
void Object::AddForce(Vec2 force)
{
	forceAccumulator += force;
}

void Object::AddImpulse(Vec2 impulse)
{
	velocity += impulse * mass;
}