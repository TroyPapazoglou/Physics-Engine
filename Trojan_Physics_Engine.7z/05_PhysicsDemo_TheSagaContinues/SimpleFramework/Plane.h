#pragma once
#include "Object.h"
#include "Maths.h"
class Plane : public Object {
public:
	Vec2 planeNormal;
	Vec2 planeTangent = Vec2(0, 0);
	float displacement;
	Plane(glm::vec2 normal, float x , float y, float displacement);
	~Plane();


	glm::vec2 GetNormal() { return m_normal; }
	float GetDistance() { return m_distanceToOrigin; }

	virtual void DebugDraw(LineRenderer* lines) const override;

	virtual ShapeType GetType() const override { return ShapeType::Plane; }

protected:
	glm::vec2 m_normal;
	float m_distanceToOrigin;
};

