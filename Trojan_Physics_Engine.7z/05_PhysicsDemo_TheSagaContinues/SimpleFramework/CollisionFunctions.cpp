#include "CollisionFunctions.h"

#include "Circle.h"
#include "Box.h"
#include "Plane.h"

CollisionData GetCollision(Object* object1, Object* object2)
{
	ShapeType object1Type = object1->GetType();
	ShapeType object2Type = object2->GetType();

	if (object1Type == ShapeType::Circle)
	{
		if (object2Type == ShapeType::Circle)
		{
			return CollideCircleWithCircle((Circle*)object1, (Circle*)object2);
		}
		if (object2Type == ShapeType::Box)
		{
			return CollideCircleWithBox((Circle*)object1, (Box*)object2);
		}
		if (object2Type == ShapeType::Plane)
		{
			return CollideCircleWithPlane((Circle*)object1, (Plane*)object2);
		}
	}
	if (object1Type == ShapeType::Plane)
	{
		if (object2Type == ShapeType::Box)
		{
			return CollidePlaneWithBox((Plane*)object1, (Box*)object2);
		}
		if (object2Type == ShapeType::Plane)
		{
			return CollidePlaneWithPlane((Plane*)object1, (Plane*)object2);
		}
		if (object2Type == ShapeType::Circle)
		{
			return CollideCircleWithPlane((Circle*)object2, (Plane*)object1);
		}
	}
	if (object1Type == ShapeType::Box)
	{
		if (object2Type == ShapeType::Circle)
		{
			return CollideCircleWithBox((Circle*)object2, (Box*)object1);
		}
		if (object2Type == ShapeType::Box)
		{
			return CollideBoxWithBox((Box*)object1, (Box*)object2);
		}
		if (object2Type == ShapeType::Plane)
		{
			return CollidePlaneWithBox((Plane*)object2, (Box*)object1);
		}
	}

	
	return CollisionData();
}

CollisionData CollideCircleWithCircle(Circle* object1, Circle* object2)
{
	Vec2 displacement = object2->position - object1->position;
	float centreDistance = glm::length(displacement);
	
	float overlapAmount = -centreDistance + object1->GetRadius() + object2->GetRadius();
	
	CollisionData data;
	data.depth = overlapAmount;
	if (centreDistance == 0) 
	{
		data.normal = Vec2(1, 1);
	}
	else 
	{
		data.normal = displacement / centreDistance;
	}	
	data.object1 = object1;
	data.object2 = object2;
	return data;
}

CollisionData CollideCircleWithPlane(Circle* object1, Plane* object2)
{

	float overlapAmount = -(glm::dot(object1->position, object2->planeNormal) - object2->displacement - object1->GetRadius());

	CollisionData data;
	data.depth = overlapAmount;
	data.normal = -object2->planeNormal;
	data.object1 = object1;
	data.object2 = object2;
	return data;

	
}

CollisionData CollideCircleWithBox(Circle* object1, Box* object2)
{

	float xMin = object2->position.x - object2->width / 2.0f;
	float xMax = object2->position.x + object2->width / 2.0f;
	float yMin = object2->position.y - object2->height / 2.0f;
	float yMax = object2->position.y + object2->height / 2.0f;



	Vec2 clampedCentre = glm::clamp(object1->position, Vec2(xMin, yMin), Vec2(xMax, yMax));
	//Point from 1 to 2, the circle is 1, the box is 2
	Vec2 displacement = clampedCentre - object1->position;
			
	float centreDistance = glm::length(displacement);

	float overlapAmount = -centreDistance + object1->GetRadius();

	CollisionData data;
	
	data.normal = displacement / centreDistance;
	data.object1 = object1;
	data.object2 = object2;
	

	if (centreDistance <= 0.0f)
	{
		//TODO something else
		//We have to handle overlaps greater than the radius of the circle (ie the circle centre is inside the box)
		float leftDistance = object1->position.x - xMin;
		float rightDistance = xMax - object1->position.x;
		float bottomDistance = object1->position.y - yMin;
		float topDistance = yMax - object1->position.y;

		float overLapDepth = SmallestOfFour(leftDistance, rightDistance, bottomDistance, topDistance);

		if (overLapDepth == leftDistance) {
			data.normal = Vec2(1, 0);
		}

		if (overLapDepth == rightDistance) {
			data.normal = Vec2(-1, 0);
		}

		if (overLapDepth == bottomDistance) {
			data.normal = Vec2(0, 1);
		}

		if (overLapDepth == topDistance) {
			data.normal = Vec2(0, -1);
		}
			

		data.depth = overLapDepth + object1->GetRadius();
		return data;
	}
	else
	{
		data.depth = overlapAmount;
		return data;
	}
			
}

CollisionData CollidePlaneWithBox(Plane* object1, Box* object2)
{

	Vec2 TopLeftVertex = Vec2(object2->position.x - object2->width / 2.0f, object2->position.y + object2->height / 2.0f);
	Vec2 TopRightVertex = Vec2(object2->position.x + object2->width / 2.0f, object2->position.y + object2->height / 2.0f);
	Vec2 BottomLeftVertex = Vec2(object2->position.x - object2->width / 2.0f , object2->position.y - object2->height / 2.0f);
	Vec2 BottomRightVertex = Vec2(object2->position.x + object2->width / 2.0f , object2->position.y - object2->height / 2.0f);

 	float overlapTopLeft = -(glm::dot(TopLeftVertex, object1->planeNormal) - object1->displacement);
	float overlapTopRight = -(glm::dot(TopRightVertex, object1->planeNormal) - object1->displacement);
	float overlapBottomLeft = -(glm::dot(BottomLeftVertex, object1->planeNormal) - object1->displacement);
	float overlapBottomRight = -(glm::dot(BottomRightVertex, object1->planeNormal) - object1->displacement);

	float overlapDepth = BiggestOfFour(overlapTopLeft, overlapTopRight, overlapBottomLeft, overlapBottomRight);

	CollisionData data;
	data.object1 = object1;
	data.object2 = object2;	
	data.normal = object1->planeNormal;
	data.depth = overlapDepth;
	return data;

}


CollisionData CollideBoxWithBox(Box* object1, Box* object2)
{
	float xMin1 = object1->position.x - object1->width / 2.0f;
	float xMax1 = object1->position.x + object1->width / 2.0f;
	float yMin1 = object1->position.y - object1->height / 2.0f;
	float yMax1 = object1->position.y + object1->height / 2.0f;

	float xMin2 = object2->position.x - object2->width / 2.0f;
	float xMax2 = object2->position.x + object2->width / 2.0f;
	float yMin2 = object2->position.y - object2->height / 2.0f;
	float yMax2 = object2->position.y + object2->height / 2.0f;

	float horizontalOverlapA = xMax2 - xMin1;
	float horizontalOverlapB = xMax1 - xMin2;

	float verticalOverlapA = yMax2 - yMin1;
	float verticalOverlapB = yMax1 - yMin2;

	CollisionData data;
	data.object1 = object1;
	data.object2 = object2;

	if (horizontalOverlapA < horizontalOverlapB && horizontalOverlapA < verticalOverlapA && horizontalOverlapA < verticalOverlapB)
	{
		//horizontal A is the smallest overlap 
		data.depth = horizontalOverlapA;
		data.normal = Vec2(-1, 0);
	}
	else if (horizontalOverlapB < verticalOverlapA && horizontalOverlapB < verticalOverlapB)
	{
		//horizontal B is the smallest overlap 
		data.depth = horizontalOverlapB;
		data.normal = Vec2(1, 0);
	}
	else if (verticalOverlapA < verticalOverlapB)
	{
		//vertical A is the smallest overlap 
		data.depth = verticalOverlapA;
		data.normal = Vec2(0, -1);
	}
	else
	{
		//vertical B is the smallest overlap
		data.depth = verticalOverlapB;
		data.normal = Vec2(0, 1);
	}
	return data;

}



CollisionData CollidePlaneWithPlane(Plane* object1, Plane* object2)
{
	return CollisionData();
}

float BiggestOfFour(float a, float b, float c, float d) 
{
	if (a > b && a > c && a > d)
		return a;
	if (b > c && b > d)
		return b;
	if (c > d)
		return c;
	else
		return d;
}

float SmallestOfFour(float a, float b, float c, float d)
{
	if (a < b && a < c && a < d)
		return a;
	if (b < c && b < d)
		return b;
	if (c < d)
		return c;
	else
		return d;
}