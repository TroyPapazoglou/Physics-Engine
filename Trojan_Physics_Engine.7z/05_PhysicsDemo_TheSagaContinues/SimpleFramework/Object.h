#pragma once

#include "Maths.h"
#include "LineRenderer.h"

enum class ShapeType
{
	Circle,
	Box,
	Plane
};

class Object
{
protected:
	
	Vec2 forceAccumulator;
public:
	Vec2 position;
	Vec2 velocity;
	Vec2 acceleration;
	float mass = 0.1f;

	//Thing() {}
	Object(float xPos, float yPos, float mass);

	void Update(float delta);

	virtual void DebugDraw(LineRenderer* lines) const = 0;

	virtual ShapeType GetType() const = 0;

	void SetMass(float m_mass);
	void AddForce(Vec2 force);
	void AddImpulse(Vec2 impulse);
};