#pragma once

#include "Object.h"
#include "CollisionData.h"

class Plane;
class Box;
class Circle;

CollisionData GetCollision(Object* object1, Object* object2);

CollisionData CollideCircleWithCircle(Circle* object1, Circle* object2);
CollisionData CollideCircleWithPlane(Circle* object1, Plane* object2);
CollisionData CollideCircleWithBox(Circle* object1, Box* object2);

CollisionData CollidePlaneWithPlane(Plane* object1, Plane* object2);
CollisionData CollidePlaneWithBox(Plane* object1, Box* object2);

CollisionData CollideBoxWithBox(Box* object1, Box* object2);

float BiggestOfFour(float a, float b, float c, float d);

float SmallestOfFour(float a, float b, float c, float d);