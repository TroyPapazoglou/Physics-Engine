#include "Box.h"

Box::Box(float x, float y, float width, float height, float mass) : Object(x,y,mass), width(width), height(height)
{

}

void Box::DebugDraw(LineRenderer* lines) const
{    	

    lines->DrawLineSegment(Vec2(position.x - (width / 2.0), position.y - (height / 2.0)),Vec2(position.x + (width / 2.0), position.y - (height / 2.0)));

  
    lines->DrawLineSegment(Vec2(position.x + (width / 2.0), position.y - (height / 2.0)),Vec2(position.x + (width / 2.0), position.y + (height / 2.0)));

   
    lines->DrawLineSegment(Vec2(position.x + (width / 2.0), position.y + (height / 2.0)),Vec2(position.x - (width / 2.0), position.y + (height / 2.0)));

   
    lines->DrawLineSegment(Vec2(position.x - (width / 2.0), position.y + (height / 2.0)),Vec2(position.x - (width / 2.0), position.y - (height / 2.0)));

}
