#include "CollisionData.h"

void CollisionData::PerformDepenetrationStep()
{
	if (depth <= 0) return;

	float totalMass = object1->mass + object2->mass;

	object2->position += normal * depth * object2->mass / totalMass;
	object1->position -= normal * depth * object1->mass / totalMass;

	float impulseMag = -(0.5f + 1.0f) * (glm::dot(object1->velocity - object2->velocity, normal)) / (object1->mass + object2->mass);

	object1->AddImpulse(impulseMag * normal);
	object2->AddImpulse(-(impulseMag * normal));
}
